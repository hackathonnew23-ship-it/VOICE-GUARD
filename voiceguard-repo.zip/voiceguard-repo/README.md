# VoiceGuard: real-time deepfake voice detection with a live trust score

VoiceGuard listens to a call as it happens and keeps a live **0 to 100 trust score**, so a cloned voice is flagged before you act on it.

- **Event:** Bits2Wave (BMSIT, IEEE ComSoc and AP-S student chapters)
- **Problem statement code:** SW-40
- **Problem:** detect AI-generated (deepfake) voices on live calls in real time and show a trust score that updates continuously during the call
- **Team:** Hackvectors. Team leader: Jeevan M Gowda. Member: Pranav S J

![Clone detected](docs/screenshots/01-clone-detected.jpg)

## Features

| Feature | What it does |
| --- | --- |
| Live trust score | 0 to 100 score updated about 15 times a second, shown on a 3D voice orb |
| Detector ensemble | Four detectors vote: spectral detail, pitch movement, loudness rhythm, timbre drift |
| Liveness challenge | Ask the caller to repeat a random phrase; the result adjusts the score |
| Family safe word | A secret word a clone cannot know; the result adjusts the score |
| Scam-pressure checks | Tick-box signals plus a live transcript that highlights phrases like OTP and gift card |
| Overall call risk | Voice trust blended with scam signals into Low, Medium or High |
| Alerts and report | Red alert with a safe call-back checklist, copyable family warning, incident report |
| Signal view | Live spectrogram and a 60-second trust history with event markers |
| Demos | Real caller, cloned voice, caller who switches to a clone, plus a scripted guided demo |
| Vigil, the robot guide | Animated guide with a spotlight tour and quick answers |
| Privacy | All audio is analyzed in the browser and never uploaded |

## How it works

```
Mic / audio file / call stream
        |
  Web Audio API (2048-point FFT, ~15 frames/s)
        |
  Feature extraction: high-frequency ratio, pitch (autocorrelation),
  loudness variation, spectral-centroid drift
        |
  Detector ensemble (weights 30 / 30 / 20 / 20) -> smoothed score
        |
  Trust engine: + liveness challenge + safe word + sensitivity -> verdict
        |
  UI: 3D orb, spectrogram, history graph, alert, report

Parallel text lane: SpeechRecognition API -> scam-phrase matcher -> call-risk blend
```

## Run it

It is a single static file with no build step.

```bash
git clone <your-repo-url>
cd <your-repo>
python3 -m http.server 8000
# open http://localhost:8000
```

The microphone needs `https://` or `localhost`, so use the command above or GitHub Pages rather than double-clicking the file.

Three.js (3D scene) and Google Fonts load from a CDN, so an internet connection is needed for the full look.

## Deploy on GitHub Pages

1. Push this repo to GitHub.
2. Settings, Pages, "Deploy from a branch", branch `main`, folder `/ (root)`.
3. Your site appears at `https://<username>.github.io/<repo>/`.

## Tech stack

HTML5, CSS, vanilla JavaScript, Web Audio API, Three.js (r128), SpeechRecognition API (Chrome and other supporting browsers).

## Honest limitations

- The four detectors use fixed signal rules, not a trained model, so results on noisy lines or unusual voices can be wrong.
- The demos are simulations that show the full flow; the microphone and file modes analyze real audio.
- Speech-to-text for scam phrases depends on browser support.

## Roadmap

1. Replace each detector slot with a trained anti-spoofing model (for example AASIST or RawNet2) running on-device.
2. Tune thresholds on public spoofing datasets.
3. Ship as a browser extension and call-app plug-in, then connect to WebRTC and carrier call streams.

## Screenshots

| Detection | Alert |
| --- | --- |
| ![Signal and detectors](docs/screenshots/02-signal-and-detectors.jpg) | ![Alert popup](docs/screenshots/03-alert-popup.jpg) |

| Verification tools | Guide |
| --- | --- |
| ![Safe word and scam checks](docs/screenshots/04-safe-word-and-scam-checks.jpg) | ![Vigil guide](docs/screenshots/05-vigil-guide.jpg) |

The orb layer in two of these screenshots was composited behind the real page because the capture browser could not load the 3D library. Run the app to see the live 3D scene.

## Pitch deck

[docs/VoiceGuard_Bits2Wave.pptx](docs/VoiceGuard_Bits2Wave.pptx)

## Source for the statistic used in the deck

Hiya, "1 in 4 calls reviewed by Hiya contain AI-generated audio" (May 2025): 25% of 8,455 analyzed calls in its honeypot contained AI-generated audio, and 55% of those were fraud.

## License

MIT, see [LICENSE](LICENSE).
